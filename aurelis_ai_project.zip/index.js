import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();
const app = express();
app.use(express.json());

// Inicializa OpenAI
const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Simulación de búsqueda externa (para reemplazar más tarde)
async function searchInternet(query) {
  return `Resultados verificados sobre: ${query}`;
}

app.post("/aurelis", async (req, res) => {
  const { userMessage } = req.body;

  const internetData = await searchInternet(userMessage);

  const basePrompt = `
Aurelis es una IA seria, educada y directa. Usa siempre conceptos en **_negrita y cursiva_**.
Responde solo información relevante. Aquí tienes los datos externos:

${internetData}
  `;

  const completion = await client.chat.completions.create({
    model: "gpt-4.1",
    messages: [
      { role: "system", content: basePrompt },
      { role: "user", content: userMessage }
    ]
  });

  res.json({
    answer: completion.choices[0].message.content
  });
});

app.listen(3000, () => console.log("Aurelis está activa en http://localhost:3000"));
